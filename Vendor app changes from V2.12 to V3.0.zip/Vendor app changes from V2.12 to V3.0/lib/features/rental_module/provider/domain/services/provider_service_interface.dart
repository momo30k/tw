

abstract class ProviderServiceInterface {

}