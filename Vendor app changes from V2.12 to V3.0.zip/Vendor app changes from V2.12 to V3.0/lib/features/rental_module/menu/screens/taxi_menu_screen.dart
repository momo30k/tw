import 'package:flutter/material.dart';

class TaxiMenuScreen extends StatelessWidget {
  const TaxiMenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
