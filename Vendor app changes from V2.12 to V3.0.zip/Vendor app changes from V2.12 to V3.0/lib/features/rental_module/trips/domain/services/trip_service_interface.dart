abstract class TripServiceInterface{

}