abstract class TaxiCouponServiceInterface {

}