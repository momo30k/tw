import 'package:sixam_mart_store/interface/repository_interface.dart';

abstract class TaxiBannerRepositoryInterface extends RepositoryInterface {

}