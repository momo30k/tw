abstract class TaxiBannerServiceInterface {

}